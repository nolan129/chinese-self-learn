import { Pressable, StyleSheet, Text } from "react-native";
import { Token } from "../data/mockData";
import { colors, radius } from "../theme/theme";

export function TokenChip({
  token,
  onPress
}: {
  token: Token;
  onPress: () => void;
}) {
  const disabled = !token.is_learnable || token.token_type === "punctuation";

  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        token.status === "known" && styles.known,
        token.status === "unknown" && styles.unknown,
        token.status === "review" && styles.review,
        token.status === "ignored" && styles.ignored,
        disabled && styles.disabled,
        pressed && !disabled ? styles.pressed : null
      ]}
    >
      <Text style={styles.text}>{token.text}</Text>
      {token.status !== "unselected" && token.pinyin ? (
        <Text style={styles.pinyin}>{token.pinyin}</Text>
      ) : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  chip: {
    minWidth: 58,
    minHeight: 48,
    borderRadius: radius.chip,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 12,
    paddingVertical: 8
  },
  known: {
    backgroundColor: colors.knownSoft
  },
  unknown: {
    backgroundColor: colors.unknownSoft,
    borderColor: colors.unknown
  },
  review: {
    backgroundColor: colors.reviewSoft,
    borderColor: colors.review
  },
  ignored: {
    backgroundColor: colors.ignoredSoft,
    opacity: 0.56
  },
  disabled: {
    opacity: 0.42
  },
  pressed: {
    transform: [{ translateY: 1 }]
  },
  text: {
    fontSize: 21,
    fontWeight: "700",
    color: colors.text
  },
  pinyin: {
    marginTop: 2,
    fontSize: 11,
    color: colors.textMuted
  }
});
