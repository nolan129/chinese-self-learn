import { Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { colors, radius } from "../theme/theme";

export function ScreenHeader({
  title,
  subtitle
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <View style={styles.header}>
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
}

export function Card({ children, style }: { children: React.ReactNode; style?: object }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Button({
  label,
  variant = "primary",
  onPress,
  disabled
}: {
  label: string;
  variant?: "primary" | "secondary" | "danger" | "soft";
  onPress: () => void;
  disabled?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        variant === "primary" && styles.primaryButton,
        variant === "secondary" && styles.secondaryButton,
        variant === "danger" && styles.dangerButton,
        variant === "soft" && styles.softButton,
        pressed && !disabled ? styles.pressed : null,
        disabled ? styles.disabled : null
      ]}
    >
      <Text
        style={[
          styles.buttonText,
          variant === "primary" ? styles.primaryButtonText : styles.secondaryButtonText,
          variant === "danger" ? styles.dangerButtonText : null,
          variant === "soft" ? styles.softButtonText : null
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

export function Field({
  value,
  onChangeText,
  placeholder,
  multiline
}: {
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  multiline?: boolean;
}) {
  return (
    <TextInput
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor={colors.textSoft}
      multiline={multiline}
      textAlignVertical={multiline ? "top" : "center"}
      style={[styles.input, multiline ? styles.textarea : null]}
    />
  );
}

const styles = StyleSheet.create({
  header: {
    gap: 8,
    marginBottom: 22
  },
  title: {
    fontSize: 38,
    lineHeight: 40,
    letterSpacing: -2,
    color: colors.text,
    fontWeight: "800"
  },
  subtitle: {
    fontSize: 15,
    lineHeight: 22,
    color: colors.textMuted
  },
  card: {
    borderRadius: radius.card,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 18,
    shadowColor: colors.text,
    shadowOpacity: 0.06,
    shadowRadius: 22,
    shadowOffset: { width: 0, height: 12 }
  },
  button: {
    minHeight: 50,
    borderRadius: radius.button,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 18,
    borderWidth: 1
  },
  primaryButton: {
    backgroundColor: colors.accent,
    borderColor: colors.accent
  },
  secondaryButton: {
    backgroundColor: colors.surface,
    borderColor: colors.border
  },
  dangerButton: {
    backgroundColor: colors.dangerSoft,
    borderColor: colors.dangerSoft
  },
  softButton: {
    backgroundColor: colors.accentSoft,
    borderColor: colors.accentSoft
  },
  buttonText: {
    fontSize: 15,
    fontWeight: "700"
  },
  primaryButtonText: {
    color: "#FFFFFF"
  },
  secondaryButtonText: {
    color: colors.text
  },
  dangerButtonText: {
    color: colors.danger
  },
  softButtonText: {
    color: colors.accentDark
  },
  pressed: {
    transform: [{ scale: 0.98 }]
  },
  disabled: {
    opacity: 0.55
  },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.input,
    backgroundColor: "#FFFDF8",
    color: colors.text,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16
  },
  textarea: {
    minHeight: 180,
    lineHeight: 24
  }
});
