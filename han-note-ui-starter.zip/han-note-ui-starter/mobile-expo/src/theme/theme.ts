export const colors = {
  bg: "#F6F4EF",
  surface: "#FFFFFF",
  surfaceMuted: "#ECE8DF",
  surfaceStrong: "#E2DDD2",
  text: "#20231F",
  textMuted: "#6B6F68",
  textSoft: "#8B8F87",
  border: "#DCD7CC",
  accent: "#0F766E",
  accentDark: "#115E59",
  accentSoft: "#D9F2ED",
  known: "#64748B",
  knownSoft: "#E2E8F0",
  unknown: "#B45309",
  unknownSoft: "#FEF3C7",
  review: "#0F766E",
  reviewSoft: "#CCFBF1",
  ignored: "#A8A29E",
  ignoredSoft: "#F5F5F4",
  danger: "#B91C1C",
  dangerSoft: "#FEE2E2",
  success: "#166534",
  successSoft: "#DCFCE7"
};

export const radius = {
  card: 22,
  chip: 14,
  button: 999,
  input: 16
};

export const spacing = {
  pageX: 18,
  gap: 14
};
