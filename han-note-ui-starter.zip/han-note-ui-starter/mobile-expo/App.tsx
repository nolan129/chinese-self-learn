import { useMemo, useState } from "react";
import {
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { Card, Button, Field, ScreenHeader } from "./src/components/Primitives";
import { TokenChip } from "./src/components/TokenChip";
import { colors, spacing } from "./src/theme/theme";
import { explanations, initialTokens, Token, TokenStatus, vocabulary } from "./src/data/mockData";

type Tab = "learn" | "review" | "vocabulary" | "settings";
type LearnMode = "input" | "result" | "explanation";
type ReviewMode = "home" | "session" | "complete";

export default function App() {
  const [tab, setTab] = useState<Tab>("learn");
  const [learnMode, setLearnMode] = useState<LearnMode>("input");
  const [reviewMode, setReviewMode] = useState<ReviewMode>("home");

  function switchTab(next: Tab) {
    setTab(next);
    if (next === "learn") setLearnMode("input");
    if (next === "review") setReviewMode("home");
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.app}>
        <ScrollView contentContainerStyle={styles.content}>
          {tab === "learn" && learnMode === "input" ? (
            <LearnHome
              onAnalyzed={() => setLearnMode("result")}
              onReview={() => switchTab("review")}
            />
          ) : null}

          {tab === "learn" && learnMode === "result" ? (
            <AnalyzeResult
              onExplain={() => setLearnMode("explanation")}
              onBack={() => setLearnMode("input")}
            />
          ) : null}

          {tab === "learn" && learnMode === "explanation" ? (
            <ExplanationScreen
              onBack={() => setLearnMode("result")}
              onReview={() => {
                setTab("review");
                setReviewMode("session");
              }}
            />
          ) : null}

          {tab === "review" && reviewMode === "home" ? (
            <ReviewHome onStart={() => setReviewMode("session")} />
          ) : null}

          {tab === "review" && reviewMode === "session" ? (
            <ReviewSession onFinish={() => setReviewMode("complete")} />
          ) : null}

          {tab === "review" && reviewMode === "complete" ? (
            <ReviewComplete
              onLearn={() => switchTab("learn")}
              onReview={() => setReviewMode("home")}
            />
          ) : null}

          {tab === "vocabulary" ? <VocabularyScreen /> : null}
          {tab === "settings" ? <SettingsScreen /> : null}
        </ScrollView>

        <TabBar active={tab} onChange={switchTab} />
      </View>
    </SafeAreaView>
  );
}

function LearnHome({
  onAnalyzed,
  onReview
}: {
  onAnalyzed: () => void;
  onReview: () => void;
}) {
  const [text, setText] = useState("你看见他吗？");

  return (
    <View>
      <ScreenHeader
        title="Hán Note"
        subtitle="Học từ tiếng Trung trong những đoạn chat công việc."
      />

      <Card>
        <Text style={styles.sectionTitle}>Bạn muốn đọc câu nào?</Text>
        <Field
          value={text}
          onChangeText={setText}
          multiline
          placeholder="Dán tiếng Trung ở đây. Ví dụ: 你看见他吗？"
        />
        <Text style={styles.counter}>{text.length} / 2.000 ký tự</Text>
        <Button label="Phân tích" onPress={onAnalyzed} disabled={!text.trim()} />
        <Text style={styles.privacy}>
          Không lưu toàn bộ đoạn chat. Chỉ từ bạn chọn học mới được lưu vào kho từ vựng.
        </Text>
      </Card>

      <Card style={{ marginTop: 14 }}>
        <Text style={styles.sectionTitle}>Hôm nay</Text>
        <Text style={styles.bigNumber}>12</Text>
        <Text style={styles.muted}>từ cần ôn</Text>
        <View style={{ height: 12 }} />
        <Button label="Ôn ngay" variant="soft" onPress={onReview} />
      </Card>
    </View>
  );
}

function AnalyzeResult({
  onExplain,
  onBack
}: {
  onExplain: () => void;
  onBack: () => void;
}) {
  const [tokens, setTokens] = useState<Token[]>(initialTokens);
  const [selected, setSelected] = useState<Token | null>(null);

  const selectedCount = useMemo(
    () => tokens.filter((item) => item.status === "unknown" || item.status === "review").length,
    [tokens]
  );

  function updateToken(status: TokenStatus) {
    if (!selected) return;
    setTokens((current) =>
      current.map((item) =>
        item.token_index === selected.token_index ? { ...item, status } : item
      )
    );
    setSelected(null);
  }

  return (
    <View>
      <Pressable onPress={onBack}>
        <Text style={styles.back}>← Kết quả phân tích</Text>
      </Pressable>

      <Card>
        <Text style={styles.zhLarge}>你看见他吗？</Text>
        <Text style={styles.translation}>Bạn có thấy anh ấy không?</Text>
        <Text style={styles.muted}>Người nói đang hỏi bạn có nhìn thấy hoặc gặp người đó không.</Text>

        <View style={styles.tokenWrap}>
          {tokens.map((token) => (
            <TokenChip key={token.token_index} token={token} onPress={() => setSelected(token)} />
          ))}
        </View>
      </Card>

      <View style={styles.stickyMobileAction}>
        <Text style={styles.stickyText}>{selectedCount} từ đã chọn để học</Text>
        <Button label={`Giải nghĩa ${selectedCount} từ`} onPress={onExplain} disabled={selectedCount === 0} />
      </View>

      <Modal visible={!!selected} transparent animationType="slide" onRequestClose={() => setSelected(null)}>
        <Pressable style={styles.sheetBackdrop} onPress={() => setSelected(null)} />
        <View style={styles.sheet}>
          {selected ? (
            <>
              <Text style={styles.sheetWord}>{selected.text}</Text>
              <Text style={styles.muted}>{selected.pinyin} · {selected.meaning_vi_brief}</Text>
              <Text style={styles.sectionTitle}>Bạn muốn xử lý từ này thế nào?</Text>
              <View style={{ gap: 10 }}>
                <Button label="Đã biết" variant="secondary" onPress={() => updateToken("known")} />
                <Button label="Chưa biết" variant="secondary" onPress={() => updateToken("unknown")} />
                <Button label="Muốn ôn lại" variant="secondary" onPress={() => updateToken("review")} />
                <Button label="Bỏ qua" variant="secondary" onPress={() => updateToken("ignored")} />
              </View>
            </>
          ) : null}
        </View>
      </Modal>
    </View>
  );
}

function ExplanationScreen({
  onBack,
  onReview
}: {
  onBack: () => void;
  onReview: () => void;
}) {
  return (
    <View>
      <Pressable onPress={onBack}>
        <Text style={styles.back}>← Giải nghĩa</Text>
      </Pressable>

      {explanations.map((item, index) => (
        <Card key={item.word} style={{ marginBottom: 14 }}>
          <Text style={styles.counter}>{index + 1} / {explanations.length}</Text>
          <Text style={styles.zhLarge}>{item.word}</Text>
          <Text style={styles.muted}>{item.pinyin} · {item.part_of_speech}</Text>

          <Detail title="Nghĩa" body={item.meaning_vi} />
          <Detail title="Trong ngữ cảnh" body={item.meaning_in_context_vi} />
          <Detail title="Ghi chú" body={item.usage_note_vi} />

          <View style={styles.example}>
            <Text style={styles.exampleZh}>{item.example_zh}</Text>
            <Text style={styles.muted}>{item.example_pinyin}</Text>
            <Text style={styles.translation}>{item.example_vi}</Text>
          </View>
        </Card>
      ))}

      <Button label="Lưu và ôn ngay" onPress={onReview} />
    </View>
  );
}

function ReviewHome({ onStart }: { onStart: () => void }) {
  return (
    <View>
      <ScreenHeader title="Ôn hôm nay" subtitle="Một từ, một quyết định, khoảng 6 phút." />
      <Card>
        <Text style={styles.bigNumber}>12</Text>
        <Text style={styles.sectionTitle}>từ đang chờ bạn</Text>
        <Text style={styles.muted}>Những từ khó sẽ quay lại sớm hơn.</Text>
        <View style={{ height: 14 }} />
        <Button label="Bắt đầu ôn" onPress={onStart} />
      </Card>

      <Card style={{ marginTop: 14 }}>
        <Text style={styles.sectionTitle}>Sắp ôn</Text>
        <View style={styles.tokenWrap}>
          {vocabulary.map((item) => (
            <View key={item.id} style={styles.previewChip}>
              <Text style={styles.previewWord}>{item.word}</Text>
              <Text style={styles.previewPinyin}>{item.pinyin}</Text>
            </View>
          ))}
        </View>
      </Card>
    </View>
  );
}

function ReviewSession({ onFinish }: { onFinish: () => void }) {
  const [index, setIndex] = useState(0);
  const [answerVisible, setAnswerVisible] = useState(false);
  const item = vocabulary[index];

  function submit() {
    if (index >= vocabulary.length - 1) {
      onFinish();
      return;
    }
    setIndex((value) => value + 1);
    setAnswerVisible(false);
  }

  return (
    <View>
      <Card style={styles.reviewCard}>
        <Text style={styles.counter}>{index + 1} / {vocabulary.length}</Text>
        <Text style={styles.reviewWord}>{item.word}</Text>
        <Text style={styles.muted}>{item.pinyin}</Text>

        {!answerVisible ? (
          <>
            <Text style={styles.prompt}>Bạn nhớ nghĩa của từ này không?</Text>
            <Button label="Xem đáp án" onPress={() => setAnswerVisible(true)} />
          </>
        ) : (
          <>
            <Text style={styles.meaning}>{item.meaning_vi}</Text>
            <View style={styles.example}>
              <Text style={styles.exampleZh}>{item.example_zh}</Text>
              <Text style={styles.translation}>{item.example_vi}</Text>
            </View>

            <View style={styles.resultGrid}>
              <Button label="Quên" variant="danger" onPress={submit} />
              <Button label="Mơ hồ" variant="secondary" onPress={submit} />
              <Button label="Nhớ" variant="soft" onPress={submit} />
              <Button label="Dễ" variant="soft" onPress={submit} />
            </View>
          </>
        )}
      </Card>
    </View>
  );
}

function ReviewComplete({
  onLearn,
  onReview
}: {
  onLearn: () => void;
  onReview: () => void;
}) {
  return (
    <View>
      <Card>
        <Text style={styles.sectionTitle}>Đã ôn xong hôm nay</Text>
        <Text style={styles.muted}>12 từ đã ôn. 7 nhớ tốt, 3 mơ hồ, 2 quên. 3 từ sẽ quay lại vào ngày mai.</Text>
        <View style={{ height: 14 }} />
        <Button label="Học thêm từ mới" onPress={onLearn} />
        <View style={{ height: 10 }} />
        <Button label="Về trang ôn" variant="secondary" onPress={onReview} />
      </Card>
    </View>
  );
}

function VocabularyScreen() {
  return (
    <View>
      <ScreenHeader title="Từ vựng" subtitle="128 từ đã lưu trong kho học cá nhân." />
      <Field value="" onChangeText={() => {}} placeholder="Tìm từ, pinyin, nghĩa tiếng Việt" />
      <View style={{ height: 14 }} />

      {vocabulary.map((item) => (
        <Card key={item.id} style={{ marginBottom: 12 }}>
          <Text style={styles.wordListText}>{item.word}</Text>
          <Text style={styles.muted}>{item.pinyin}</Text>
          <Text style={styles.translation}>{item.meaning_vi}</Text>
          <Text style={styles.counter}>{item.next_review_label} · {item.difficulty}</Text>
        </Card>
      ))}
    </View>
  );
}

function SettingsScreen() {
  return (
    <View>
      <ScreenHeader title="Cài đặt" subtitle="Nhắc ôn, Telegram và quyền riêng tư." />
      <Card>
        <Text style={styles.sectionTitle}>Nhắc ôn</Text>
        <Text style={styles.settingRow}>Giờ nhắc: 21:00</Text>
        <Text style={styles.settingRow}>Timezone: Asia/Bangkok</Text>
      </Card>

      <Card style={{ marginTop: 14 }}>
        <Text style={styles.sectionTitle}>Thông báo</Text>
        <Text style={styles.settingRow}>Push notification: bật</Text>
        <Text style={styles.settingRow}>Telegram: bật</Text>
        <Text style={styles.settingRow}>Chat ID: 123456789</Text>
        <Button label="Gửi thử Telegram" variant="secondary" onPress={() => {}} />
      </Card>

      <Card style={{ marginTop: 14 }}>
        <Text style={styles.sectionTitle}>Quyền riêng tư</Text>
        <Text style={styles.muted}>
          Không lưu toàn bộ đoạn chat đã dán. Chỉ lưu từ bạn chọn học và câu ví dụ ngắn.
        </Text>
        <Text style={styles.settingRow}>Không lưu câu nguồn: tắt</Text>
        <Text style={styles.settingRow}>Ẩn danh tên riêng: tắt</Text>
      </Card>
    </View>
  );
}

function Detail({ title, body }: { title: string; body: string }) {
  return (
    <View style={styles.detail}>
      <Text style={styles.detailTitle}>{title}</Text>
      <Text style={styles.muted}>{body}</Text>
    </View>
  );
}

function TabBar({
  active,
  onChange
}: {
  active: Tab;
  onChange: (tab: Tab) => void;
}) {
  const tabs: { key: Tab; label: string }[] = [
    { key: "learn", label: "Học" },
    { key: "review", label: "Ôn" },
    { key: "vocabulary", label: "Từ vựng" },
    { key: "settings", label: "Cài đặt" }
  ];

  return (
    <View style={styles.tabbar}>
      {tabs.map((tab) => (
        <Pressable
          key={tab.key}
          onPress={() => onChange(tab.key)}
          style={[styles.tab, active === tab.key && styles.activeTab]}
        >
          <Text style={[styles.tabText, active === tab.key && styles.activeTabText]}>
            {tab.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.bg
  },
  app: {
    flex: 1,
    backgroundColor: colors.bg
  },
  content: {
    paddingHorizontal: spacing.pageX,
    paddingTop: 18,
    paddingBottom: 110
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "800",
    letterSpacing: -0.7,
    color: colors.text,
    marginBottom: 10
  },
  counter: {
    color: colors.textSoft,
    fontSize: 12,
    marginVertical: 10
  },
  privacy: {
    marginTop: 12,
    color: colors.accentDark,
    lineHeight: 20,
    backgroundColor: colors.accentSoft,
    padding: 12,
    borderRadius: 14
  },
  bigNumber: {
    fontSize: 62,
    lineHeight: 66,
    letterSpacing: -4,
    color: colors.text,
    fontWeight: "900"
  },
  muted: {
    color: colors.textMuted,
    lineHeight: 22
  },
  back: {
    color: colors.accentDark,
    fontWeight: "800",
    marginBottom: 16
  },
  zhLarge: {
    fontSize: 46,
    lineHeight: 52,
    letterSpacing: -2,
    color: colors.text,
    fontWeight: "900"
  },
  translation: {
    color: colors.text,
    lineHeight: 22,
    marginTop: 6
  },
  tokenWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginTop: 18
  },
  stickyMobileAction: {
    marginTop: 14,
    borderRadius: 24,
    backgroundColor: colors.text,
    padding: 14,
    gap: 10
  },
  stickyText: {
    color: "#FFFFFF",
    fontWeight: "700"
  },
  sheetBackdrop: {
    flex: 1,
    backgroundColor: "rgba(32,35,31,0.3)"
  },
  sheet: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    padding: 20,
    gap: 14
  },
  sheetWord: {
    fontSize: 40,
    fontWeight: "900",
    letterSpacing: -2,
    color: colors.text
  },
  detail: {
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: 14,
    marginTop: 14
  },
  detailTitle: {
    color: colors.text,
    fontWeight: "800",
    marginBottom: 6
  },
  example: {
    backgroundColor: colors.surfaceMuted,
    borderRadius: 16,
    padding: 14,
    marginTop: 14
  },
  exampleZh: {
    fontSize: 22,
    color: colors.text,
    fontWeight: "800"
  },
  previewChip: {
    backgroundColor: colors.reviewSoft,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 14
  },
  previewWord: {
    fontSize: 20,
    fontWeight: "800",
    color: colors.text
  },
  previewPinyin: {
    fontSize: 11,
    color: colors.textMuted
  },
  reviewCard: {
    minHeight: 560,
    justifyContent: "center"
  },
  reviewWord: {
    fontSize: 96,
    lineHeight: 110,
    letterSpacing: -6,
    textAlign: "center",
    fontWeight: "900",
    color: colors.text
  },
  prompt: {
    textAlign: "center",
    color: colors.textMuted,
    lineHeight: 22,
    marginVertical: 24
  },
  meaning: {
    fontSize: 22,
    fontWeight: "800",
    color: colors.text,
    textAlign: "center",
    marginTop: 22
  },
  resultGrid: {
    gap: 10,
    marginTop: 18
  },
  wordListText: {
    fontSize: 34,
    color: colors.text,
    fontWeight: "900",
    letterSpacing: -2
  },
  settingRow: {
    color: colors.text,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: colors.border
  },
  tabbar: {
    position: "absolute",
    left: 12,
    right: 12,
    bottom: 12,
    minHeight: 68,
    borderRadius: 28,
    backgroundColor: "rgba(255,255,255,0.92)",
    borderWidth: 1,
    borderColor: colors.border,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    padding: 8
  },
  tab: {
    flex: 1,
    minHeight: 48,
    borderRadius: 999,
    alignItems: "center",
    justifyContent: "center"
  },
  activeTab: {
    backgroundColor: colors.accentSoft
  },
  tabText: {
    color: colors.textMuted,
    fontWeight: "700"
  },
  activeTabText: {
    color: colors.accentDark
  }
});
