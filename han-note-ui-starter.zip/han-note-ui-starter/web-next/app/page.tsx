"use client";

import { useState } from "react";
import { AppHeader } from "../components/AppHeader";
import { AnalyzeScreen } from "../components/AnalyzeScreen";
import { ExplanationScreen } from "../components/ExplanationScreen";
import { ReviewComplete, ReviewHome, ReviewSession } from "../components/ReviewScreen";
import { SettingsScreen } from "../components/SettingsScreen";
import { VocabularyScreen } from "../components/VocabularyScreen";

type PageKey =
  | "analyze"
  | "explanation"
  | "review"
  | "review-session"
  | "review-complete"
  | "vocabulary"
  | "settings";

export default function Page() {
  const [page, setPage] = useState<PageKey>("analyze");

  const navPage =
    page === "explanation"
      ? "analyze"
      : page === "review-session" || page === "review-complete"
        ? "review"
        : page;

  return (
    <div className="app-shell">
      <AppHeader
        activePage={navPage as "analyze" | "review" | "vocabulary" | "settings"}
        dueCount={12}
        onNavigate={(next) => setPage(next)}
      />

      <main className="main">
        {page === "analyze" ? (
          <AnalyzeScreen
            onExplain={() => setPage("explanation")}
            onReview={() => setPage("review")}
          />
        ) : null}

        {page === "explanation" ? (
          <ExplanationScreen
            onVocabulary={() => setPage("vocabulary")}
            onReview={() => setPage("review-session")}
          />
        ) : null}

        {page === "review" ? (
          <ReviewHome onStart={() => setPage("review-session")} />
        ) : null}

        {page === "review-session" ? (
          <ReviewSession onFinish={() => setPage("review-complete")} />
        ) : null}

        {page === "review-complete" ? (
          <ReviewComplete
            onAnalyze={() => setPage("analyze")}
            onReview={() => setPage("review")}
          />
        ) : null}

        {page === "vocabulary" ? <VocabularyScreen /> : null}
        {page === "settings" ? <SettingsScreen /> : null}
      </main>
    </div>
  );
}
