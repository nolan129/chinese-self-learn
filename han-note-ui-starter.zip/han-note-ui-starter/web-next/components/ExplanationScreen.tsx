import { explanations } from "../lib/mockData";

export function ExplanationScreen({
  onVocabulary,
  onReview
}: {
  onVocabulary: () => void;
  onReview: () => void;
}) {
  return (
    <section>
      <h1 className="page-title">Giải nghĩa</h1>
      <p className="page-copy">
        Mỗi từ được giải thích bằng tiếng Việt, kèm ngữ cảnh, ghi chú sử dụng và ví dụ.
      </p>

      <div className="explanation-layout">
        <aside className="panel pad context-card">
          <h2 className="panel-title">Ngữ cảnh câu</h2>
          <p className="sentence-zh" style={{ fontSize: 38 }}>你看见他吗？</p>
          <p className="translation">Bạn có thấy anh ấy không?</p>

          <div className="token-row">
            {explanations.map((item) => (
              <span key={item.word} className="token review">
                <span>{item.word}</span>
                <small style={{ display: "block" }}>{item.pinyin}</small>
              </span>
            ))}
          </div>
        </aside>

        <div style={{ display: "grid", gap: 18 }}>
          {explanations.map((item) => (
            <article className="panel explanation-card" key={item.word}>
              <h2 className="word-heading">{item.word}</h2>
              <p className="meta">
                {item.pinyin} · {item.part_of_speech}
              </p>

              <div className="detail-section">
                <h3>Nghĩa</h3>
                <p>{item.meaning_vi}</p>
              </div>

              <div className="detail-section">
                <h3>Trong ngữ cảnh</h3>
                <p>{item.meaning_in_context_vi}</p>
              </div>

              <div className="detail-section">
                <h3>Ghi chú sử dụng</h3>
                <p>{item.usage_note_vi}</p>
              </div>

              <div className="detail-section">
                <h3>Ví dụ</h3>
                <div style={{ display: "grid", gap: 12 }}>
                  {item.examples.map((example) => (
                    <div className="example" key={example.zh}>
                      <div className="zh">{example.zh}</div>
                      <p className="meta">{example.pinyin}</p>
                      <p>{example.vi}</p>
                    </div>
                  ))}
                </div>
              </div>
            </article>
          ))}

          <div className="sticky-action">
            <span>Đã sẵn sàng lưu {explanations.length} từ vào kho học</span>
            <div className="actions">
              <button className="btn btn-secondary" onClick={onVocabulary}>
                Đến kho từ vựng
              </button>
              <button className="btn btn-primary" onClick={onReview}>
                Lưu và ôn ngay
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
