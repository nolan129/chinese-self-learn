import { useMemo, useState } from "react";
import { reviewItems } from "../lib/mockData";

export function ReviewHome({ onStart }: { onStart: () => void }) {
  return (
    <section>
      <h1 className="page-title">Ôn hôm nay</h1>
      <p className="page-copy">Một phiên ôn ngắn, mỗi từ một quyết định.</p>

      <div className="review-hero">
        <div className="panel pad">
          <h2 className="panel-title">12 từ đang chờ bạn</h2>
          <p className="panel-copy">Khoảng 6 phút. Những từ khó sẽ quay lại sớm hơn.</p>
          <button className="btn btn-primary" onClick={onStart}>
            Bắt đầu ôn
          </button>
        </div>

        <div className="panel pad">
          <h2 className="panel-title">Sắp ôn</h2>
          <div className="due-preview" style={{ marginTop: 16 }}>
            {reviewItems.map((item) => (
              <span className="token review" key={item.id}>
                <span>{item.word}</span>
                <small style={{ display: "block" }}>{item.pinyin}</small>
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="review-hero">
        <div className="stat">
          <strong>12</strong>
          <span>đến hạn</span>
        </div>
        <div className="stat">
          <strong>4</strong>
          <span>từ khó nhớ</span>
        </div>
      </div>
    </section>
  );
}

export function ReviewSession({ onFinish }: { onFinish: () => void }) {
  const [index, setIndex] = useState(0);
  const [answerVisible, setAnswerVisible] = useState(false);
  const current = reviewItems[index];

  const progress = useMemo(() => `${index + 1} / ${reviewItems.length}`, [index]);

  function submit() {
    if (index >= reviewItems.length - 1) {
      onFinish();
      return;
    }
    setIndex((value) => value + 1);
    setAnswerVisible(false);
  }

  return (
    <section>
      <h1 className="page-title">Review session</h1>

      <article className="panel pad review-card">
        <p className="meta">{progress}</p>
        <h2 className="review-word">{current.word}</h2>
        <p className="meta">{current.pinyin}</p>

        {!answerVisible ? (
          <>
            <p className="panel-copy" style={{ marginInline: "auto" }}>
              Bạn nhớ nghĩa của từ này không?
            </p>
            <button className="btn btn-primary" onClick={() => setAnswerVisible(true)}>
              Xem đáp án
            </button>
          </>
        ) : (
          <div className="review-answer">
            <div className="detail-section">
              <h3>Nghĩa</h3>
              <p>{current.meaning_vi}</p>
            </div>

            <div className="detail-section">
              <h3>Ví dụ</h3>
              <div className="example">
                <div className="zh">{current.example_zh}</div>
                <p>{current.example_vi}</p>
              </div>
            </div>

            <div className="result-buttons">
              <button className="btn forgot" onClick={submit}>Quên</button>
              <button className="btn vague" onClick={submit}>Mơ hồ</button>
              <button className="btn remembered" onClick={submit}>Nhớ</button>
              <button className="btn easy" onClick={submit}>Dễ</button>
            </div>
          </div>
        )}
      </article>
    </section>
  );
}

export function ReviewComplete({
  onAnalyze,
  onReview
}: {
  onAnalyze: () => void;
  onReview: () => void;
}) {
  return (
    <section>
      <div className="panel empty">
        <h2>Đã ôn xong hôm nay</h2>
        <p>12 từ đã ôn. 7 nhớ tốt, 3 mơ hồ, 2 quên. 3 từ sẽ quay lại vào ngày mai.</p>
        <div className="actions" style={{ justifyContent: "center" }}>
          <button className="btn btn-secondary" onClick={onReview}>
            Về trang ôn
          </button>
          <button className="btn btn-primary" onClick={onAnalyze}>
            Học thêm từ mới
          </button>
        </div>
      </div>
    </section>
  );
}
