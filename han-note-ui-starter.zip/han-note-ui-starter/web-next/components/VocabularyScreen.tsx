import { useMemo, useState } from "react";
import { vocabulary } from "../lib/mockData";

type VocabItem = (typeof vocabulary)[number];

export function VocabularyScreen() {
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState(vocabulary[0].id);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return vocabulary;
    return vocabulary.filter((item) =>
      [item.word, item.pinyin, item.meaning_vi].some((value) =>
        value.toLowerCase().includes(normalized)
      )
    );
  }, [query]);

  const selected = filtered.find((item) => item.id === selectedId) ?? filtered[0];

  return (
    <section>
      <h1 className="page-title">Vocabulary</h1>
      <p className="page-copy">Kho từ cá nhân, tập trung vào nghĩa tiếng Việt và ngữ cảnh công việc.</p>

      <div className="toolbar">
        <input
          className="input"
          placeholder="Tìm từ, pinyin hoặc nghĩa tiếng Việt"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
        />
        <select className="select" defaultValue="all">
          <option value="all">Tất cả</option>
          <option value="due">Cần ôn</option>
          <option value="learning">Đang học</option>
          <option value="hard">Khó nhớ</option>
          <option value="mastered">Đã thuộc</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <div className="panel empty">
          <h2>Không tìm thấy từ phù hợp</h2>
          <p>Thử tìm bằng tiếng Trung, pinyin hoặc nghĩa tiếng Việt ngắn hơn.</p>
        </div>
      ) : (
        <div className="vocabulary-layout">
          <div className="panel pad">
            <div className="word-list">
              {filtered.map((item) => (
                <WordListItem
                  key={item.id}
                  item={item}
                  active={selected?.id === item.id}
                  onClick={() => setSelectedId(item.id)}
                />
              ))}
            </div>
          </div>

          {selected ? <VocabularyDetail item={selected} /> : null}
        </div>
      )}
    </section>
  );
}

function WordListItem({
  item,
  active,
  onClick
}: {
  item: VocabItem;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button className={`word-item ${active ? "active" : ""}`} onClick={onClick}>
      <strong>{item.word}</strong>
      <p>{item.pinyin}</p>
      <p>{item.meaning_vi}</p>
      <small>{item.next_review_label} · {item.difficulty}</small>
    </button>
  );
}

function VocabularyDetail({ item }: { item: VocabItem }) {
  return (
    <article className="panel explanation-card">
      <h2 className="word-heading">{item.word}</h2>
      <p className="meta">{item.pinyin} · {item.part_of_speech}</p>

      <div className="detail-section">
        <h3>Nghĩa</h3>
        <p>{item.meaning_vi}</p>
      </div>

      <div className="detail-section">
        <h3>Trong ngữ cảnh</h3>
        <p>{item.meaning_in_context_vi}</p>
      </div>

      <div className="detail-section">
        <h3>Ghi chú sử dụng</h3>
        <p>{item.usage_note_vi}</p>
      </div>

      <div className="detail-section">
        <h3>Ví dụ đã lưu</h3>
        <div className="example">
          <div className="zh">{item.example_zh}</div>
          <p>{item.example_vi}</p>
        </div>
      </div>

      <div className="detail-section">
        <h3>Lịch ôn</h3>
        <p>Stage {item.review_stage}. Đã ôn {item.review_count} lần. Lần tiếp theo: {item.next_review_label}.</p>
      </div>

      <div className="actions" style={{ marginTop: 22 }}>
        <button className="btn btn-primary">Ôn từ này</button>
        <button className="btn btn-secondary">Đánh dấu đã thuộc</button>
      </div>
    </article>
  );
}
