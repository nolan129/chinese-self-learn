type PageKey = "analyze" | "review" | "vocabulary" | "settings";

const items: { key: PageKey; label: string }[] = [
  { key: "analyze", label: "Analyze" },
  { key: "review", label: "Review" },
  { key: "vocabulary", label: "Vocabulary" },
  { key: "settings", label: "Settings" }
];

export function AppHeader({
  activePage,
  onNavigate,
  dueCount
}: {
  activePage: PageKey;
  onNavigate: (page: PageKey) => void;
  dueCount: number;
}) {
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <div className="brand">
          <strong>Hán Note</strong>
          <span>Chinese vocabulary desk</span>
        </div>

        <nav className="nav" aria-label="Primary navigation">
          {items.map((item) => (
            <button
              key={item.key}
              type="button"
              className={activePage === item.key ? "active" : ""}
              onClick={() => onNavigate(item.key)}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="due-pill">{dueCount} due today</div>
      </div>
    </header>
  );
}
