import { useState } from "react";

export function SettingsScreen() {
  const [pushEnabled, setPushEnabled] = useState(true);
  const [telegramEnabled, setTelegramEnabled] = useState(true);
  const [noSourceSentence, setNoSourceSentence] = useState(false);
  const [anonymize, setAnonymize] = useState(false);

  return (
    <section>
      <h1 className="page-title">Settings</h1>
      <p className="page-copy">Quản lý giờ nhắc, kênh thông báo và cách Hán Note lưu ví dụ.</p>

      <div className="settings-grid">
        <div className="panel pad setting-row">
          <div>
            <h2 className="panel-title">Nhắc ôn</h2>
            <p className="panel-copy">Tính theo timezone của bạn.</p>
          </div>
          <div className="actions">
            <label>
              <span className="meta">Giờ nhắc</span>
              <input className="input" type="time" defaultValue="21:00" />
            </label>
            <label>
              <span className="meta">Timezone</span>
              <input className="input" value="Asia/Bangkok" readOnly />
            </label>
          </div>
        </div>

        <div className="panel pad setting-row">
          <div>
            <h2 className="panel-title">Kênh thông báo</h2>
            <p className="panel-copy">Mỗi kênh chỉ gửi một nhắc ôn mỗi ngày.</p>
          </div>
          <div>
            <Toggle label="Push notification" enabled={pushEnabled} onToggle={() => setPushEnabled((v) => !v)} />
            <Toggle label="Telegram" enabled={telegramEnabled} onToggle={() => setTelegramEnabled((v) => !v)} />

            <label style={{ display: "block", marginTop: 14 }}>
              <span className="meta">Telegram chat ID</span>
              <input className="input" defaultValue="123456789" />
            </label>

            <button className="btn btn-secondary" style={{ marginTop: 14 }}>
              Gửi thử Telegram
            </button>
          </div>
        </div>

        <div className="panel pad setting-row">
          <div>
            <h2 className="panel-title">Quyền riêng tư</h2>
            <p className="panel-copy">
              Hán Note không lưu toàn bộ lịch sử chat. App chỉ lưu từ bạn chọn học và ví dụ ngắn gắn với từ đó.
            </p>
          </div>
          <div>
            <label className="checkbox-row">
              <input
                type="checkbox"
                checked={noSourceSentence}
                onChange={() => setNoSourceSentence((value) => !value)}
              />
              <span>Không lưu câu nguồn từ nội dung đã dán</span>
            </label>
            <label className="checkbox-row">
              <input
                type="checkbox"
                checked={anonymize}
                onChange={() => setAnonymize((value) => !value)}
              />
              <span>Ẩn danh tên riêng trước khi lưu ví dụ</span>
            </label>
          </div>
        </div>
      </div>
    </section>
  );
}

function Toggle({
  label,
  enabled,
  onToggle
}: {
  label: string;
  enabled: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="toggle-row">
      <span>{label}</span>
      <button
        className={`switch ${enabled ? "on" : ""}`}
        type="button"
        aria-pressed={enabled}
        onClick={onToggle}
      >
        <span />
      </button>
    </div>
  );
}
