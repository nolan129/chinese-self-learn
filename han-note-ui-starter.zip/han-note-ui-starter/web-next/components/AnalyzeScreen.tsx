import { useMemo, useState } from "react";
import { initialTokens, Token, TokenStatus } from "../lib/mockData";
import { TokenChip, TokenStatusPicker } from "./TokenChip";

export function AnalyzeScreen({
  onExplain,
  onReview
}: {
  onExplain: () => void;
  onReview: () => void;
}) {
  const [text, setText] = useState("你看见他吗？");
  const [hasAnalyzed, setHasAnalyzed] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [tokens, setTokens] = useState<Token[]>(initialTokens);
  const [selectedTokenIndex, setSelectedTokenIndex] = useState<number | null>(null);
  const selectedToken = tokens.find((token) => token.token_index === selectedTokenIndex);

  const selectedCount = useMemo(
    () => tokens.filter((token) => token.status === "unknown" || token.status === "review").length,
    [tokens]
  );

  function analyze() {
    if (!text.trim()) return;
    setIsLoading(true);
    setTimeout(() => {
      setHasAnalyzed(true);
      setIsLoading(false);
    }, 520);
  }

  function updateTokenStatus(status: TokenStatus) {
    if (selectedTokenIndex === null) return;
    setTokens((current) =>
      current.map((token) =>
        token.token_index === selectedTokenIndex ? { ...token, status } : token
      )
    );
  }

  return (
    <>
      <section>
        <h1 className="page-title">Analyze</h1>
        <p className="page-copy">
          Dán đoạn tiếng Trung, xem token theo đơn vị có nghĩa, rồi chọn đúng những từ bạn muốn học.
        </p>

        <div className="grid-two">
          <div className="panel pad">
            <h2 className="panel-title">Bạn muốn đọc câu nào?</h2>
            <p className="panel-copy">
              Hán Note phân tích nội dung tạm thời và chỉ lưu những từ bạn chọn học.
            </p>

            <textarea
              className="textarea"
              value={text}
              maxLength={2000}
              onChange={(event) => setText(event.target.value)}
              placeholder="Dán một câu hoặc đoạn chat tiếng Trung ở đây. Ví dụ: 你看见他吗？"
            />

            <div className="form-row">
              <span className="counter">{text.length} / 2.000 ký tự</span>
              <div className="actions">
                <button className="btn btn-secondary" onClick={() => setText("")}>
                  Xóa
                </button>
                <button className="btn btn-primary" onClick={analyze} disabled={isLoading}>
                  {isLoading ? "Đang phân tích..." : "Phân tích"}
                </button>
              </div>
            </div>

            <div className="privacy-note">
              Không lưu toàn bộ đoạn chat đã dán. Chỉ từ bạn chọn học mới được lưu vào kho từ vựng.
            </div>
          </div>

          <aside className="panel pad">
            <h2 className="panel-title">Hôm nay</h2>
            <p className="panel-copy">Tổng quan nhẹ để bạn biết nên học mới hay ôn trước.</p>

            <div className="snapshot-grid">
              <div className="stat">
                <strong>12</strong>
                <span>từ cần ôn hôm nay</span>
              </div>
              <div className="stat">
                <strong>128</strong>
                <span>từ trong kho học</span>
              </div>
            </div>

            <div className="actions" style={{ marginTop: 16 }}>
              <button className="btn btn-primary" onClick={onReview}>
                Ôn hôm nay
              </button>
            </div>
          </aside>
        </div>
      </section>

      {hasAnalyzed ? (
        <section className="result-stack">
          <div className="panel sentence-card">
            <p className="sentence-zh">你看见他吗？</p>
            <p className="translation">Bạn có thấy anh ấy không?</p>
            <p className="natural">
              Người nói đang hỏi bạn có nhìn thấy hoặc gặp người đó không.
            </p>

            <div className="token-row">
              {tokens.map((token) => (
                <TokenChip
                  key={token.token_index}
                  token={token}
                  selected={selectedTokenIndex === token.token_index}
                  onClick={() => setSelectedTokenIndex(token.token_index)}
                />
              ))}
            </div>
          </div>

          {selectedToken ? (
            <TokenStatusPicker token={selectedToken} onSelect={updateTokenStatus} />
          ) : null}

          {selectedCount > 0 ? (
            <div className="sticky-action">
              <span>{selectedCount} từ đã chọn để học</span>
              <button className="btn btn-primary" onClick={onExplain}>
                Giải nghĩa {selectedCount} từ
              </button>
            </div>
          ) : null}
        </section>
      ) : null}
    </>
  );
}
